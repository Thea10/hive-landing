const Themes = {
  dark: {
    background: "dark",
  },
  light: {
    background: "light",
  },
};

export { Themes };
